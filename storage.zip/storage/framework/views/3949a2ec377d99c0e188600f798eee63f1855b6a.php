<?php $__env->startSection('title'); ?> 
Edit Company
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<h1><?php echo $__env->yieldContent('title'); ?><!-- <small></small> --></h1>
<ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active"><a href="<?php echo e(url('admin/companies')); ?>">Company</a></li>
    <li class="active"><a href="<?php echo e(route('companies.edit', ['id' => $company->id])); ?>"><?php echo $__env->yieldContent('title'); ?></a></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_custom'); ?>
<link href="<?php echo e(URL::asset('assets/admin/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style type="text/css">
	.select2-container .select2-selection--single{
		height: 34px;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="content">

		<?php if(isset($company->id)): ?>
			<div class="row" style="margin-bottom: 15px;">
				<div class="col-md-4 text-center" style="margin-bottom: 15px;">
					<button class="btn btn-success btn-block productTextAjax" type="button" thirdparty="tinymce"
					target="<?php echo e(route('companies.edit', ['id' => $company->id, 'ajax' => 1])); ?>">Company Detail</button>
				</div>

				<div class="col-md-4 text-center" style="margin-bottom: 15px;">
					<button class="btn btn-success btn-block productTextAjax" type="button"
					target="<?php echo e(route('companies.get-employee', ['id' => $company->id])); ?>">Employee List</button>
				</div>

				<div class="col-md-4 text-center" style="margin-bottom: 15px;">
					<button class="btn btn-success btn-block productTextAjax" type="button" 
					target="<?php echo e(route('companies.get-related-company', ['id' => $company->id])); ?>">Related Company</button>
				</div>
			</div>
		<?php endif; ?>


		<form action="<?php echo e(route('companies.update',$company->id)); ?>" method="post" enctype="multipart/form-data" id="upload_form">
		<?php echo e(csrf_field()); ?>

		<?php if(isset($company->id)): ?>
			<input type="hidden" name="id" value="<?php echo e($company->id); ?>" />
			<input type="hidden" name="_method" value="PUT" />
		<?php endif; ?>

		<div id="ajaxLoad">

		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>

		<?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
    <?php endif; ?>

		<div class="box box-success">
	    <div class="box-header with-border">
	      <h3 class="box-title">Company Prospect</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-minus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">

	              			<div class="form-group">
			                  <label for="CompanyName" class="col-sm-3 control-label">Company name</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->CompanyName) ? $company->CompanyName : old('CompanyName')); ?>" placeholder="Company name" name="CompanyName">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="CompanyNumber" class="col-sm-3 control-label">Company number</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->CompanyNumber) ? $company->CompanyNumber : old('CompanyNumber')); ?>" placeholder="Company number" name="CompanyNumber">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="phone2" class="col-sm-3 control-label">Phone 2</label>

			                  <div class="col-sm-9">
			                  	<input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->phone2) ? $company->phone2 : old('phone2')); ?>" placeholder="Phone 2" name="phone2">
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="phone3" class="col-sm-3 control-label">Customer</label>

			                  <div class="col-sm-9">
			                  	<input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->phone3) ? $company->phone3 : old('phone3')); ?>" placeholder="Phone 3" name="phone3">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="ClassificationID" class="col-sm-3 control-label">Classification</label>

			                  <div class="col-sm-9">
			                  	<select name="ClassificationID" class="form-control">
			                  		<?php $__currentLoopData = $classification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kclass => $vclass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                  			<option value="<?php echo e($vclass['key']); ?>"><?php echo e($vclass['val']); ?></option>
			                  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                  	</select>
			                  </div>
			                </div>
			                
		                </div>

		                
		                <div class="col-md-6">
		                	
		                	<div class="form-group">
			                  <label for="Email" class="col-sm-3 control-label">Company email</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->Email) ? $company->Email : old('Email')); ?>" placeholder="Company email" name="Email">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="WWW" class="col-sm-3 control-label">Company website</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->WWW) ? $company->WWW : old('WWW')); ?>" placeholder="Company website" name="WWW">
			                  </div>
			                </div>

		                	<div class="form-group">
			                  <label for="phone1" class="col-sm-3 control-label">Phone</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->phone1) ? $company->phone1 : old('phone1')); ?>" placeholder="Phone 1" name="phone1">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Active" class="col-sm-3 control-label">Active</label>

			                  <div class="col-sm-9">
			                  	<?php if($company->Active == 0): ?>
			                    	<input type="checkbox" unchecked name="Active" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="Active" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Type" class="col-sm-3 control-label">Type</label>

			                  <div class="col-sm-9">
			                  	<select name="Type" class="form-control">
			                  		<?php $__currentLoopData = $type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ktype => $vtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                  			<option value="<?php echo e($vtype['key']); ?>"><?php echo e($vtype['val']); ?></option>
			                  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                  	</select>
			                  </div>
			                </div>

		                </div>
	                </div>
	            </div>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>




		<div class="box box-success">
	    <div class="box-header with-border">
	      <h3 class="box-title">Economy</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-minus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">
			                
			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Term of delivery</label>

			                  <div class="col-sm-9">
			                  	<textarea name="DeliveryCondition">
			                  		<?php echo e(isset($company->DeliveryCondition) ? $company->DeliveryCondition : old('DeliveryCondition')); ?>

			                  	</textarea>
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Vat outgoing account</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VatOutAccount) ? $company->VatOutAccount : old('VatOutAccount')); ?>" placeholder="Vat outgoing account" name="VatOutAccount">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Vat invesment account</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->VatInvestmentAccount) ? $company->VatInvestmentAccount : old('VatInvestmentAccount')); ?>" 
			                    placeholder="Vat invesment account" name="VatInvestmentAccount">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Account for sale</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->AccountSale) ? $company->AccountSale : old('AccountSale')); ?>" placeholder="Account Sale" name="AccountSale">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Hour price</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->HourPrice) ? $company->HourPrice : old('HourPrice')); ?>" placeholder="Hour Price" name="HourPrice">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Cost price</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->CostPrice) ? $company->CostPrice : old('CostPrice')); ?>" placeholder="Cost Price" name="CostPrice">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">PKP Number</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->PKPNumber) ? $company->PKPNumber : old('PKPNumber')); ?>" placeholder="PKP Number" name="PKPNumber">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="EnableSaleNumberSequence" class="col-sm-3 control-label">Turn on salesnumbering</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableSaleNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableSaleNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableSaleNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="EnableCashNumberSequence" class="col-sm-3 control-label">Turn on cash numbering</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableCashNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableCashNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableCashNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="EnableSalaryNumberSequence" class="col-sm-3 control-label">Turn on salary numbering</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableSalaryNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableSalaryNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableSalaryNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="EnableWeeklysaleNumberSequence" class="col-sm-3 control-label">Turn on weekly salesnumbering</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableWeeklysaleNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableWeeklysaleNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableWeeklysaleNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                
		                </div>

		                
		                <div class="col-md-6">
		                	<div class="form-group">
			                  <label for="QuantityPerUnit" class="col-sm-3 control-label">Term of payment</label>

			                  <div class="col-sm-9">
			                  	<textarea name="PaymentCondition">
			                  			<?php echo e(isset($company->PaymentCondition) ? $company->PaymentCondition : old('PaymentCondition')); ?>

			                  	</textarea>
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Vat incomming account</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VatInAccount) ? $company->VatInAccount : old('VatInAccount')); ?>" placeholder="Vat incomming account" name="VatInAccount">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Vat account</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->VatAccount) ? $company->VatAccount : old('VatAccount')); ?>" 
			                    placeholder="Vat account" name="VatAccount">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Account investment</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->AccountInvestment) ? $company->AccountInvestment : old('AccountInvestment')); ?>" 
			                    placeholder="Account Investment" name="AccountInvestment">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Travel price</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->TravelPrice) ? $company->TravelPrice : old('TravelPrice')); ?>" placeholder="Travel Price" name="TravelPrice">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">Account plan ID</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->AccountPlanID) ? $company->AccountPlanID : old('AccountPlanID')); ?>" placeholder="Account plan ID" 
			                    name="AccountPlanID">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Unit" class="col-sm-3 control-label">PKP Used Date</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" id="PKPUsedDate" readonly="true" 
			                    value="<?php echo e(isset($company->PKPUsedDate) ? $company->PKPUsedDate : old('PKPUsedDate')); ?>" placeholder="PKP Used Date" name="PKPUsedDate">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="EnableBankNumberSequence" class="col-sm-3 control-label">Turn on banknumber</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableBankNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableBankNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableBankNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="EnableBuyNumberSequence" class="col-sm-3 control-label">Turn on order number</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableBuyNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableBuyNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableBuyNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="EnableAutoNumberSequence" class="col-sm-3 control-label">Turn on auto numbering</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableAutoNumberSequence == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableAutoNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableAutoNumberSequence" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>
			                
		                </div>

	                </div>

	            </div	>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>



		<div class="box box-success collapsed-box">
	    <div class="box-header with-border">
	      <h3 class="box-title">Interest</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-plus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body" style="display: none;">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">
			                <div class="form-group">
			                  <label for="InterestRate" class="col-sm-3 control-label">Interest</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->InterestRate) ? $company->InterestRate : old('InterestRate')); ?>" placeholder="Interest" name="InterestRate">
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="ShareValue" class="col-sm-3 control-label">Nominal value</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->ShareValue) ? $company->ShareValue : old('ShareValue')); ?>" placeholder="Nominal value" name="ShareValue">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="VoucherBankNumber" class="col-sm-3 control-label">Voucher account number</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VoucherBankNumber) ? $company->VoucherBankNumber : old('VoucherBankNumber')); ?>" placeholder="Voucher account number" name="VoucherBankNumber">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="VoucherBuyNumber" class="col-sm-3 control-label">Voucher procurement number</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VoucherBuyNumber) ? $company->VoucherBuyNumber : old('VoucherBuyNumber')); ?>" placeholder="Voucher procurement number" name="VoucherBuyNumber">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="VoucherCashNumber" class="col-sm-3 control-label">Voucher pay desk number</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VoucherCashNumber) ? $company->VoucherCashNumber : old('VoucherCashNumber')); ?>" placeholder="Voucher pay desk number" name="VoucherCashNumber">
			                  </div>
			                </div>
		                </div>

		                <div class="col-md-6">
		                	<div class="form-group">
			                  <label for="InterestDate" class="col-sm-3 control-label">Interest day</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->InterestDate) ? $company->InterestDate : old('InterestDate')); ?>" placeholder="Interest day" name="InterestDate" id="InterestDate" readonly="true">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="ShareNumber" class="col-sm-3 control-label">Number of share</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->ShareNumber) ? $company->ShareNumber : old('ShareNumber')); ?>" placeholder="Number of share" name="ShareNumber">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="VoucherSaleNumber" class="col-sm-3 control-label">Voucher sales number</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VoucherSaleNumber) ? $company->VoucherSaleNumber : old('VoucherSaleNumber')); ?>" placeholder="Voucher sales number" name="VoucherSaleNumber">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="VoucherSalaryNumber" class="col-sm-3 control-label">Voucher salary account</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->VoucherSalaryNumber) ? $company->VoucherSalaryNumber : old('VoucherSalaryNumber')); ?>" placeholder="Voucher salary account" name="VoucherSalaryNumber">
			                  </div>
			                </div>

			                
		                </div>

	                </div>

	            </div	>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>


		<div class="box box-success collapsed-box">
	    <div class="box-header with-border">
	      <h3 class="box-title">Open Hour</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-plus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body" style="display: none;">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">
			                <div class="form-group">
			                  <label for="OpenMon" class="col-sm-3 control-label">Open Monday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenMon) ? $company->OpenMon : old('OpenMon')); ?>" placeholder="Open Monday" name="OpenMon">
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="OpenTue" class="col-sm-3 control-label">Open Tuesday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenTue) ? $company->OpenTue : old('OpenTue')); ?>" placeholder="Open Tuesday" name="OpenTue">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="OpenWed" class="col-sm-3 control-label">Open wednesday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenWed) ? $company->OpenWed : old('OpenWed')); ?>" placeholder="Open wednesday" name="OpenWed">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="OpenThu" class="col-sm-3 control-label">Open Thursday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenThu) ? $company->OpenThu : old('OpenThu')); ?>" placeholder="Open Thursday" name="OpenThu">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="OpenFri" class="col-sm-3 control-label">Open Friday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenFri) ? $company->OpenFri : old('OpenFri')); ?>" placeholder="Open Friday" name="OpenFri">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="OpenSat" class="col-sm-3 control-label">Open Saturday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenSat) ? $company->OpenSat : old('OpenSat')); ?>" placeholder="Open Saturday" name="OpenSat">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="OpenSun" class="col-sm-3 control-label">Open Sunday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->OpenSun) ? $company->OpenSun : old('OpenSun')); ?>" placeholder="Open Sunday" name="OpenSun">
			                  </div>
			                </div>
		                </div>


		                
		                <div class="col-md-6">
		                	<div class="form-group">
			                  <label for="CloseMon" class="col-sm-3 control-label">Close Monday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseMon) ? $company->CloseMon : old('CloseMon')); ?>" placeholder="Close Monday" name="CloseMon">
			                  </div>
			                </div>
			                <div class="form-group">
			                  <label for="CloseTue" class="col-sm-3 control-label">Close Tuesday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseTue) ? $company->CloseTue : old('CloseTue')); ?>" placeholder="Close Tuesday" name="CloseTue">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="CloseWed" class="col-sm-3 control-label">Close wednesday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseWed) ? $company->CloseWed : old('CloseWed')); ?>" placeholder="Close wednesday" name="CloseWed">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="CloseThu" class="col-sm-3 control-label">Close Thursday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseThu) ? $company->CloseThu : old('CloseThu')); ?>" placeholder="Close Thursday" name="CloseThu">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="CloseFri" class="col-sm-3 control-label">Close Friday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseFri) ? $company->CloseFri : old('CloseFri')); ?>" placeholder="Close Friday" name="CloseFri">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="CloseSat" class="col-sm-3 control-label">Close Saturday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseSat) ? $company->CloseSat : old('CloseSat')); ?>" placeholder="Close Saturday" name="CloseSat">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="CloseSun" class="col-sm-3 control-label">Close Sunday</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->CloseSun) ? $company->CloseSun : old('CloseSun')); ?>" placeholder="Close Sunday" name="CloseSun">
			                  </div>
			                </div>
		                </div>

	                </div>

	            </div	>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>




		<div class="box box-success collapsed-box">
	    <div class="box-header with-border">
	      <h3 class="box-title">VAT</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-plus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body" style="display: none;">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">

			                <div class="form-group">
			                  <label for="EnableTaxFree" class="col-sm-3 control-label">Turn on taxfree status</label>

			                  <div class="col-sm-9">
			                  	<?php if($company->EnableTaxFree == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableTaxFree" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableTaxFree" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Frittisisteledd" class="col-sm-3 control-label">Fritt i siste ledd</label>
			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->Frittisisteledd) ? $company->Frittisisteledd : old('Frittisisteledd')); ?>" placeholder="Fritt i siste ledd" name="Frittisisteledd">
			                  </div>
			                </div>
			              </div>

		                
		                <div class="col-md-6">

		                	<div class="form-group">
			                  <label for="EnableVat" class="col-sm-3 control-label">Turn on VAT</label>

			                  <div class="col-sm-9">
			                    <?php if($company->EnableVat == 0): ?>
			                    	<input type="checkbox" unchecked name="EnableVat" style="position: relative;top: 7px;" value="1">
			                    <?php else: ?>
			                    	<input type="checkbox" checked name="EnableVat" style="position: relative;top: 7px;" value="1">
			                    <?php endif; ?>
			                  </div>
			                </div>

		                </div>
	                </div>
	            </div>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>




		<div class="box box-success collapsed-box">
	    <div class="box-header with-border">
	      <h3 class="box-title">Various information</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-plus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body" style="display: none;">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">

	              			<div class="form-group">
			                  <label for="Status" class="col-sm-3 control-label">Status</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->Status) ? $company->Status : old('Status')); ?>" 
			                    placeholder="Status" name="Status">
			                  </div>
			                </div>
			                
			                <div class="form-group">
			                  <label for="Information" class="col-sm-3 control-label">Information about the unit</label>

			                  <div class="col-sm-9">
			                  	<textarea name="Information">
			                  		<?php echo e(isset($company->Information) ? $company->Information : old('Information')); ?>

			                  	</textarea>
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="TagLine" class="col-sm-3 control-label">Motto</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->TagLine) ? $company->TagLine : old('TagLine')); ?>" placeholder="Motto" name="TagLine">
			                  </div>
			                </div>
			                
		                </div>

		                
		                <div class="col-md-6">

			                <div class="form-group">
			                  <label for="FoundedDate" class="col-sm-3 control-label">Establish date</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->FoundedDate) ? $company->FoundedDate : old('FoundedDate')); ?>" placeholder="Establish date" name="FoundedDate" id="FoundedDate" readonly="true">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="SalePersonID" class="col-sm-3 control-label">Sales responsible</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->SalePersonID) ? $company->SalePersonID : old('SalePersonID')); ?>" 
			                    placeholder="Sales responsible" name="SalePersonID">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="AddRegCode" class="col-sm-3 control-label">Additonal Reg Code</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->AddRegCode) ? $company->AddRegCode : old('AddRegCode')); ?>" 
			                    placeholder="Additonal Reg Code" name="AddRegCode">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="OrgNumber" class="col-sm-3 control-label">Organisation number</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->OrgNumber) ? $company->OrgNumber : old('OrgNumber')); ?>" placeholder="Organisation number" name="OrgNumber">
			                  </div>
			                </div>
			                
		                </div>

	                </div>
	            </div	>
		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>



		<div class="box box-success collapsed-box">
	    <div class="box-header with-border">
	      <h3 class="box-title">Social Network</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-plus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body" style="display: none;">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">

	              			<div class="form-group">
			                  <label for="Facebook" class="col-sm-3 control-label">Facebook</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" 
			                    value="<?php echo e(isset($company->Facebook) ? $company->Facebook : old('Facebook')); ?>" 
			                    placeholder="Facebook" name="Facebook">
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Twitter" class="col-sm-3 control-label">Twitter</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->Twitter) ? $company->Twitter : old('Twitter')); ?>" placeholder="Twitter" name="Twitter">
			                  </div>
			                </div>
			                
		                </div>

		                
		                <div class="col-md-6">

			                <div class="form-group">
			                  <label for="LinkedIn" class="col-sm-3 control-label">LinkedIn</label>

			                  <div class="col-sm-9">
			                    <input type="text" class="form-control" value="<?php echo e(isset($company->LinkedIn) ? $company->LinkedIn : old('LinkedIn')); ?>" placeholder="LinkedIn" name="LinkedIn">
			                  </div>
			                </div>
			                
		                </div>

	                </div>

	            </div	>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>



		<div class="box box-success collapsed-box">
	    <div class="box-header with-border">
	      <h3 class="box-title">Log</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-plus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body" style="display: none;">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">
	              		<div class="col-md-6">

	              			<div class="form-group">
			                  <label for="Facebook" class="col-sm-3 control-label">Updated By</label>

			                  <div class="col-sm-9">
			                  	<input type="text" value="<?php echo e($company->UpdatedByPersonID); ?>" readonly="true" class="form-control" />
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="Twitter" class="col-sm-3 control-label">Created By</label>

			                  <div class="col-sm-9">
			                    <input type="text" value="<?php echo e($company->InsertedByPersonID); ?>" readonly="true" class="form-control" />
			                  </div>
			                </div>
			                
		                </div>

		                
		                <div class="col-md-6">

			                <div class="form-group">
			                  <label for="LinkedIn" class="col-sm-3 control-label">Updated</label>

			                  <div class="col-sm-9">
			                  	<input type="text" value="<?php echo e($company->updated_at); ?>" readonly="true" class="form-control" />
			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="LinkedIn" class="col-sm-3 control-label">Date when created</label>

			                  <div class="col-sm-9">
			                    <input type="text" value="<?php echo e($company->created_at); ?>" readonly="true" class="form-control" />
			                  </div>
			                </div>
						                
		                </div>

	                </div>

	            </div	>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>

	  <div class="panel">
			<div class="panel-body">
				<div class="row">
					<div class="col-md-offset-5 col-md-2 text-center">
						<a href="#" class="btn btn-default">Cancel</a>
						&nbsp;
						<input type="submit" value="Save" class="btn btn-primary" />
					</div>
				</div>
			</div>
		</div>

		</div> 

		</form>

	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addingFileJs'); ?>
	<script src="<?php echo e(URL::asset('assets/admin/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
	<script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=xspx9ax4f39yi8pjfnpoe60sz9x5mz1xewzmxt918nsl47sh"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addingScriptJs'); ?>
	<script type="text/javascript">
	$(document).ready(function() {
			$('#PKPUsedDate').datepicker({
				autoclose: true,
				orientation: 'bottom',
				format: 'yyyy-mm-dd'
		  });

		  $('#InterestDate').datepicker({
				autoclose: true,
				orientation: 'bottom',
				format: 'yyyy-mm-dd'
		  });

		  $('#FoundedDate').datepicker({
				autoclose: true,
				orientation: 'bottom',
				format: 'yyyy-mm-dd'
		  });

	    tinymce.init({
						      selector: 'textarea',
						      entity_encoding : 'raw',
						      mode : 'specific_textareas',
						      //selector: 'textarea',
						      //editor_selector : 'mceEditor',
						      convert_urls: false,
						      language : 'en',
						      theme: 'modern',
						      plugins: [
						        'spellchecker,pagebreak,layer,table,save,insertdatetime,media,searchreplace,' +
						          'print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,' +
						          'nonbreaking,template,autoresize,' +
						          'anchor,charmap,hr,image,link,emoticons,code,textcolor,' +
						          'charmap,pagebreak'
						      ],
						      toolbar: 'insertfile undo redo| charmap | pagebreak | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image |  fontselect fontsizeselect | forecolor backcolor',
						      pagebreak_separator: "<!-- my page break -->",
						      image_advtab: true,
						      autoresize_max_height: 350
						    });

	    $('body').on('click', '.productTextAjax', function(){
	    	var target = $(this).attr('target');
	    	var thirdparty = $(this).attr('thirdparty');

	    	$.ajax({
	        method:"GET",
	        url:target,
	        success: function(result){
	            $("#ajaxLoad").html(result);

	            $('#getCompanyID').select2();

	            if(thirdparty == 'tinymce'){
	            	tinymce.remove();
	            	
	            	tinymce.init({
						      selector: 'textarea',
						      entity_encoding : 'raw',
						      mode : 'specific_textareas',
						      //selector: 'textarea',
						      //editor_selector : 'mceEditor',
						      convert_urls: false,
						      language : 'en',
						      theme: 'modern',
						      plugins: [
						        'spellchecker,pagebreak,layer,table,save,insertdatetime,media,searchreplace,' +
						          'print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,' +
						          'nonbreaking,template,autoresize,' +
						          'anchor,charmap,hr,image,link,emoticons,code,textcolor,' +
						          'charmap,pagebreak'
						      ],
						      toolbar: 'insertfile undo redo| charmap | pagebreak | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image |  fontselect fontsizeselect | forecolor backcolor',
						      pagebreak_separator: "<!-- my page break -->",
						      image_advtab: true,
						      autoresize_max_height: 350
						    });
	            }
	            
	        },
	        error: function(e){
	          alert("Error");
	          console.log(e);
	        }
	      });
	    });

	    

	    $('body').on('click', '.addComRelation', function(){
	    	// alert($('#getCompanyID').val());
	    	var formData = {
	                ToCompanyID : $('#getCompanyID').val(),
	                FromCompanyID : $('#CompanyID').val(),
	                FromCompanyRelationTypeID : 0,
	                ToCompanyRelationTypeID : 0,
	                Active : 1,
	                InsertedByPersonID : <?php echo e(Auth::user()->id); ?>,
	                UpdatedByPersonID : <?php echo e(Auth::user()->id); ?>,
	                _token  : $('meta[name="csrf-token"]').attr('content'),
	                _method: 'POST',
	            }

	      console.log(formData);
	      // return false;

	      $.ajax({
	        method:"POST",
	        url:"<?php echo e(route('companies.save-related-company')); ?>",
	        data: formData,
	        //dataType: "json",
	        success: function(result){
	            console.log(result);
	            if(result.error == 0){
	              alert("Update data Success");
	              $(".companyRelatedReload").load("<?php echo e(route('companies.get-related-company',$company->id)); ?> .companyRelatedReloadSuccess");
	              $(".successCompanyRelated").fadeIn('slow');
	            }else{
	            	alert("Error when update");
	            }

	        },
	        error: function(e, r){
	          alert("Error");
	          console.log(e);
	          console.log(r);
	        }
	      });
	    });
	});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
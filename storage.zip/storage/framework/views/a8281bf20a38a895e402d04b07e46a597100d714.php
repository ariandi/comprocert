<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addingScriptJs'); ?>

<?php if(\Session::has('success')): ?>
<script>
  alert('<?php echo e(\Session::get("success")); ?>');
</script>
<?php endif; ?>
<script>
  $(document).ready(function(){
    $(".imgblog img").addClass("img-fluid");

  });

  var slideIndex = 0;
  var clicked = 1;
  showSlides(slideIndex);

  function plusSlides(n) {
    // showSlides(slideIndex += n);
    if(n == -1){
      showSlides(slideIndex += n, -1, clicked);
    }else{
      showSlides(slideIndex += n, 1, clicked);
    }
  }

  function currentSlide(n) {
    showSlides(slideIndex = n);
  }

  function showSlides(n, min1 = 0, cliked = 0) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("gmslide");
    if (n > slides.length) {slideIndex = 0}
      if (n < 0) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
          slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
          dots[i].className = dots[i].className.replace(" active", "");
        }
        if(cliked == 0){

          if(slideIndex >= slides.length){
            slideIndex = 1;
          }else{
            slideIndex++;
          }

          slides[slideIndex-1].style.display = "block";
          dots[slideIndex-1].className += " active";
          setTimeout(showSlides, 5000);

        }else{
          if(min1 == -1){
            if (n <= 0) {slideIndex = slides.length}
              slides[slideIndex-1].style.display = "block";
            dots[slideIndex-1].className += " active";
            //setTimeout(showSlides, 5000);

          }else{
            if(slideIndex >= slides.length){
              slideIndex = 1;
            }else{
              slideIndex++;
            }

            slides[slideIndex-1].style.display = "block";
            dots[slideIndex-1].className += " active";
            //setTimeout(showSlides, 5000);
          }
        }

        // slides[slideIndex-1].style.display = "block";
        // dots[slideIndex-1].className += " active";
        // setTimeout(showSlides, 2000);
      }
    </script>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
    <div class="visible-lg besar" style="margin-top: -20px;">
      <header class="gambarutama2">
       <div class="intro-body">
         <!-- <div class="col-md-12 col-lg-12">  -->
           <div class="container">
             <div class="row">
               <div class="col-lg-6 bagianbawah" style="text-align: left;">
                 <h1 class="brand-heading regulasi1" style="margin-bottom: 0px;margin-left: -20px;">
                   <img src="<?php echo e(url('assets/img/logochange66.png')); ?>" class="img-responsive" alt="" />
                 </h1>
                 <br>
                 <br>
                 <h1 style="margin: 0 0 15px;"><b style="color: #901823;text-transform: none;"><?php echo e(Menus::getLanguageString('idC66H1')); ?></b></h1>
                 <h2 style="margin: 0 0 15px;color: #901823;text-transform: none;"><?php echo e(Menus::getLanguageString('idC66H2')); ?></h2>


                 
                 <br>
                 <br>
                 <br>
                 <br>
                 <h2 style="margin: 0 0 15px;color: #901823;"><?php echo e(Menus::getLanguageString('idC66H3')); ?></h2> 



                 

               </div>
               <div class="col-md-6">
               </div>


               
        </div>
      </div>
      <!-- </div>  -->

      <div class="panel panel-info" style="opacity: 0.9;border-color: #000000;margin-top: 5px;">
        <div class="panel-heading clearfix" style="background-color: #000000;border-color: #f0f8ff00;padding-top: 35px;padding-bottom: 35px;">
          <div class="container">
            <form method="POST" action="<?php echo e(route('front.sendEmailSubscript')); ?>">
              <div class="form-group">
                <?php echo csrf_field(); ?>
                <div class="row">

                  <div class="col-md-12">
                    <div class="seperator"></div>
                    <!-- <h1 class=" pull-left" style="color: white;"><?php echo e(Menus::getLanguageString('idC66S1')); ?></h1>  -->
                    <div class="col-md-6" style="padding-left: 0px;">
                      <h3 class=" center" style="color: white;text-align: center;"><?php echo e(Menus::getLanguageString('idC66S1')); ?></h3>                     
                    </div>
                    <div class="col-md-6">
                      <h3 class=" center" style="color: white;text-align: center;"><?php echo e(Menus::getLanguageString('idC66D1')); ?></h3> 
                    </div>
                  </div>
                  
                  <div class="col-md-12">
                    <div class="seperator"></div>
                    <div class="col-md-6">
                      <p class="center" style="color: white;text-align: center;"><?php echo e(Menus::getLanguageString('idC66S2')); ?></p>  
                    </div>
                    <div class="col-md-6">
                      <p class="center" style="color: white;text-align: center;"><a href="/registerfronts" style="color: white;"><?php echo e(Menus::getLanguageString('idFuApple')); ?></a></p> 
                    </div>
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-md-12">
                    <div class="seperator"></div>
                    <div class="col-lg-6 col-md-6">
                      <div class="input-group" style="width: 100%; ">
                        <div class="seperator"></div>
                        <input type="text" name="name" class="form-control" aria-label="..." placeholder="Skriv inn navn">
                      </div><!-- /input-group -->
                      <br>
                      <div class="input-group" style="width: 100%;">
                        <input type="text" class="form-control" name="email" aria-label="..." placeholder="skriv inn e-post">
                      </div><!-- /input-group -->
                      <br>
                      <div class="input-group" style="width: 100%;text-align: left;">
                        <input type="submit" name="sendemail" tabindex="1" value="<?php echo e(Menus::getLanguageString('idC66S3')); ?>" class="btn btn-danger" id="" style="font-size: 24px;"> 
                      </div><!-- /input-group -->
                    </div><!-- /.col-lg-6 -->
                    <div class="w-100"></div>
                    <div class="col-md-3">
                      <!-- <a href='https://itunes.apple.com/us/app/change66/id1290125333?ls=1&mt=8'><img src="<?php echo e(url('assets/img/apple.png')); ?>" class="img-responsive" alt="" /></a> -->
                      <a href='https://itunes.apple.com/us/app/change66/id1290125333?ls=1&mt=8'><img src="<?php echo e(url('assets/img/apple.png')); ?>" class="img-responsive" alt="" /></a> 
                    </div>
                    <div class="col-md-3">
                      <!-- <a href='https://play.google.com/store/apps/details?id=com.wisehouse.change66v2&hl=en_US'><img src="<?php echo e(url('assets/img/googleplay.png')); ?>" class="img-responsive" alt="" /></a> -->
                      <a href='https://play.google.com/store/apps/details?id=com.wisehouse.change66v2&hl=en_US'><img src="<?php echo e(url('assets/img/googleplay.png')); ?>" class="img-responsive" alt="" /></a>
                    </div>
                  </div>
                  
                </div>
              </form>
            </div>
          </div>


          
        </div>
      </div>

      <svg class="clip-svg">
        <defs>
          <clipPath id="octagon-clip" clipPathUnits="objectBoundingBox">
            <polygon points="0.3 0, 0.7 0, 1 0.0, 1 0.7, 0.7 1, 0.3 1, 0 0.7, 0 0.0" />
          </clipPath>
        </defs>
      </svg>
    </header>
    <div class="container-fluid" style="border-top: 10px solid white">
      &nbsp;
    </div>
  </div>


  <!-- untuk layar kecil -->

  <div class="hidden-lg">

   <div class="intro-body" style="background-image:url(https://change66.no/assets/img/picrune.png);background-repeat: round;margin-top: -20px;margin-bottom: -10px;">
     
     <!-- <div class="col-md-12 col-lg-12">  -->
       <div class="container">
         <div class="row">
           <div class="col-md-12 col-xs-10" style="text-align: left;">

             <h3 class="brand-heading regulasi1" style="margin-top: 25px; margin-bottom: 0px;margin-left: -15px;">
               <img src="<?php echo e(url('assets/img/logochange66.png')); ?>" class="img-responsive" alt="" style="max-width: 65%;" />
             </h3>
             <h4 style="margin: 0 0 15px;"><b style="color: #901823;text-transform: none;"><?php echo e(Menus::getLanguageString('idC66H1')); ?></b></h4> 
             <h4 style="margin: 0 0 15px;color: #901823;text-transform: none;"><?php echo e(Menus::getLanguageString('idC66H2')); ?></h4> 

             
            <br>
            <h4 style="margin: 0 0 15px;color: #901823;"><?php echo e(Menus::getLanguageString('idC66H3')); ?></h4>


          </div>

          
      </div>
    </div>
    
  </div>

  <section id="download" class="text-center" style="background-color: #000000;margin-bottom: -10px;">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="panel-info" style="opacity: 0.9;border-color: #000000;margin-top: 5px;">
            <div class="clearfix" style="background-color: #000000;border-color: #f0f8ff00;padding-top: 35px;padding-bottom: 35px;">
              <div class="container">
                <div class="row">
                  <div class="col-md-12">
                    <h3 class="" style="color: white;"><?php echo e(Menus::getLanguageString('idC66S1')); ?></h3> 
                  </div>

                  <div class="col-md-12">
                    <p class="" style="color: white;"><?php echo e(Menus::getLanguageString('idC66S2')); ?></p> 
                  </div>
                </div>
                
                <div class="row">
                  <div class="col-lg-5">
                    <div class="input-group" style="width: 100%;">
                      <input type="text" class="form-control" aria-label="..." placeholder="Enter Name">
                    </div><!-- /input-group -->
                  </div><!-- /.col-lg-5 -->
                  <div class="col-lg-5">
                    <div class="input-group" style="width: 100%;">
                      <input type="text" class="form-control" aria-label="..." placeholder="Enter Email">
                    </div><!-- /input-group -->
                  </div><!-- /.col-lg-5 -->
                  <div class="col-lg-2" style="margin-top: -5px;">
                    <input type="submit" tabindex="1" value="<?php echo e(Menus::getLanguageString('idC66S3')); ?>" class="btn btn-danger" id="" style="font-size: 16px;"> 

                  </div><!-- /.col-lg-2 -->
                </div><!-- /.row -->
                <br>
                <br>
                <div class="row">
                  <hr style="height: 2px;background-color:white;">
                  <div class="col-md-12">
                    <h3 class="" style="color: white;text-align: center;"><?php echo e(Menus::getLanguageString('idC66D1')); ?></h3>
                    <p class="" style="color: white;text-align: center;"><a href="/registerfronts" style="color: white;"><?php echo e(Menus::getLanguageString('idFuApple')); ?></a></p>
                    <div class="col-md-12">
                     <a href='https://itunes.apple.com/us/app/change66/id1290125333?ls=1&mt=8'><img src="<?php echo e(url('assets/img/apple.png')); ?>" class="img-responsive" alt="" /></a>
                   </div>
                   <div class="col-md-12">
                    <a href='https://play.google.com/store/apps/details?id=com.wisehouse.change66v2&hl=en_US'><img src="<?php echo e(url('assets/img/googleplay.png')); ?>" class="img-responsive" alt="" /></a>
                  </div>
                </div>
              </div>

            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

</div>


<a href="https://www.wisehouse.no/internett1/index.php?t=publish.indexbaru&amp;NodeID=&amp;inline=edit" accesskey="E"></a>

<!-- About Section -->

    <!-- <div class="container-fluid" style="border-top: 10px solid white">
        &nbsp;
      </div> -->
      <br>
      <br>
      <br>

      

     <!-- Download Section -->

     <div class="container-fluid">
      <div class="row"> 
        <section class="download-section sectiondk tambahan2"></section>
        <?php $__currentLoopData = $blogchild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($b->id <> 44): ?>

        <section class="download-section sectiondk">
         <div class="container">
           <div class="row">
             <div class="col-md-4 col-xs-12 align-middle">
               <a class="imgblog">
                <img src="<?php echo e($b->imagepath?Storage::url($b->imagepath):""); ?>" title="" class="img-responsive" alt="Empatix mediabank Media ID 128" style="padding-bottom: 10px;" />


              </a>
            </div>

            <div class="col-md-8 col-xs-12">
             <h3 style=" margin: 0 0 5px;">
              <a href="<?php echo e(url($b->alias)); ?>" style="color:#000; "><?php echo e($b->title); ?></a>
            </h3>
            <?php echo substr(strip_tags($b->content2), 0, 475); ?>...
            <div style="margin-top: 20px;padding-bottom: 40px;">
              <a href="<?php echo e(url($b->alias)); ?>"><button class="btn btn-default">Read More</button></a>
            </div>
          </div>

        </div>
      </div>
    </section>

    <!-- <div class="container-fluid" style="border-bottom: 2px solid black; margin-bottom:30px; margin-top:30px;"> -->
      <!-- <div class="row"  style="background: white;"> -->
        <div class="container">
          <!-- <div class="row"> -->
            <hr style="height: 2px;">
            <!-- </div> -->
          </div>
          <!-- </div> -->
          <!-- </div> -->
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           -->

    

    <!-- Contact Section -->
    <section id="om_oss" class="content-section text-center regomos1" style="background-color: #3a3838;">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 mx-auto" style="color: white;">
           <?php echo $node_om_oss->content1; ?>

         </div>
       </div>
     </div>
   </section>

   <section id="hvor" class="content-section text-center  hvorfor">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 mx-auto">
          <?php echo $node->content2; ?>

        </div>
      </div>
    </div>
  </section>

  <!-- <section id="download" class="content-section regomos1" style="background-color: #000000;">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 mx-auto" style="color: white;">
          <div class="col-md-12">
              <h1 class=" pull-left" style="color: white;"><?php echo e(Menus::getLanguageString('idC66D1')); ?></h1>
          </div>
        </div>
          <div class="col-md-2" style="margin-top: -5px;">
            <input type="submit" tabindex="1" value="Download Now" class="btn btn-danger" id="" style="font-size: 24px;">
          </div><!-- /.col-lg-2 -->
        </div>
      </div>
    </section> -->

  </div>
</div>
<!-- Map Section -->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
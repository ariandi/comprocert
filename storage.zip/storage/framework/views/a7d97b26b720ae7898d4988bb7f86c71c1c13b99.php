<?php $__env->startSection('title'); ?>
Create Publish2
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titlecontent'); ?>
Publish2
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subtitlecontent'); ?>
create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">
  <!-- Default box -->
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Create Content Management Page</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body">
      <div class="link-back-to-list">
        <a href="<?php echo e(route('nodes.index')); ?>">Back to list</a>
        <hr />
      </div>

      <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
      <?php endif; ?>


      <?php echo Form::open(array('route' => 'node.store','method'=>'POST', 'files' => true)); ?>

        <?php echo e(method_field('post')); ?>

        <input type="hidden" value="<?php echo e($parent); ?>" name="parent">
        <div class="box-body">
          <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
            <label for="inputTitle1">Title</label>
            <?php echo Form::text('title', null, array('placeholder' => 'Field the title','class' => 'form-control')); ?>

            <?php if($errors->has('title')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('title')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group <?php echo e($errors->has('template') ? 'has-error' : ''); ?>">
            <label for="inputAlias">Template</label>
            <?php echo Form::select('template', $arrTemplates, null, ['placeholder' => 'Pick a Template','class' => 'form-control' ]); ?>

            <?php if($errors->has('template')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('template')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group <?php echo e($errors->has('alias') ? 'has-error' : ''); ?>">
            <label for="inputAlias">Alias</label>
            <?php echo Form::text('alias', null, array('placeholder' => 'Field the alias','class' => 'form-control')); ?>

            <?php if($errors->has('alias')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('alias')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
            <label for="inputDescription">Description</label>
            <?php echo Form::text('description', null, array('placeholder' => 'Field the description','class' => 'form-control')); ?>

            <?php if($errors->has('description')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('description')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group <?php echo e($errors->has('keyword') ? 'has-error' : ''); ?>">
            <label for="inputKeyword">Keyword</label>
            <?php echo Form::text('keyword', null, array('placeholder' => 'Field the keyword','class' => 'form-control')); ?>

            <?php if($errors->has('keyword')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('keyword')); ?></strong>
                </span>
            <?php endif; ?>
          </div>

          <div class="form-group <?php echo e($errors->has('content1') ? 'has-error' : ''); ?>">
            <label for="inputConten1">Content 1</label>
            <?php echo Form::textarea('content1', null, array('class' => 'form-control')); ?>

            <?php if($errors->has('keyword')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('keyword')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      <?php echo Form::close(); ?>

    </div>
    <!-- /.box-body -->
    <div class="box-footer">
      Footer
    </div>
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
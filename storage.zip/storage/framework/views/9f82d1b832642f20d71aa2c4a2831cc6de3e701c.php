<?php $__env->startSection('title'); ?>
WCS Indonesia | <?php echo e($node->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
$node->keyword
<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
$node->description
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('theme/css/about.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){
     
    });
  </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  
  <!--====================================================
                         HOME-P
  ======================================================-->
      <div id="home-p" class="home-p pages-head1 text-center">
          <div class="container">
              <?php echo $node->content4; ?>

          </div>
          <!--/end container-->
      </div>

  <!--====================================================
                          ABOUT-P1
  ======================================================-->
      <section id="about-p1">
          <div class="container">
              <div class="row">
                  <div class="col-md-8">
                      <div class="about-p1-cont">
                          <?php echo $node->content1; ?>

                      </div>
                  </div>
                  <div class="col-md-4">
                      <div class="about-p1-img">
                          <?php if( isset($node->getImages->path) ): ?>
                            <img src="<?php echo e(url(Storage::url($node->getImages->path))); ?>" class="img-fluid wow fadeInUp" data-wow-delay="0.1s" alt="...">
                          <?php endif; ?>
                      </div>
                  </div>
              </div>
          </div>
      </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
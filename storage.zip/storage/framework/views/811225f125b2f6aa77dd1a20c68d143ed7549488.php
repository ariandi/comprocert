<div class="lvl1 ajavlvl<?php echo e($lvl); ?>load">
	<div class="h-new-node">
		<img src="<?php echo e(asset('images/folder1.png')); ?>" class="img-responsive" />
	</div>
	<div class="h-new-title">
		<a href="<?php echo e(route('nodes.create', ['parent' => $parent, 'lvl' => $lvl])); ?>">New Node</a>
	</div>

	<div class="clearfix"></div>

	<div class="b-node">
		<?php $__currentLoopData = $nodes2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="c-menu-b">
			<div class="h-new-node">
				<a href="<?php echo e(route('nodes.index', ['parent' => $node2->node->id, 'lvl' => $lvl])); ?>" class="lvl<?php echo e($lvl); ?>clicked" id="<?php echo e($node2->node->id); ?>">
  				<img src="<?php echo e(asset('images/folder1.png')); ?>" class="img-responsive" />
  			</a>
  		</div>
  		<div class="h-new-title">
  			<a href="<?php echo e(route('nodes.edit', ['id' => $node2->node->id, 'parent' => $parent, 'lvl' => $lvl])); ?>">
  				<?php echo e($node2->node->title); ?> (<?php echo e($node2->node->id); ?>)
  			</a>
  		</div>

  		<div class="clearfix"></div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
</div>
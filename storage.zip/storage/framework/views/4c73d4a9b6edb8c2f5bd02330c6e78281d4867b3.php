<?php $__env->startSection('title'); ?> 
Create Certificate
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<h1><?php echo $__env->yieldContent('title'); ?></h1>
<ol class="breadcrumb">
    <li><a href="<?php echo e(url('admin/')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    <li class="active"><a href="<?php echo e(url('admin/certificates')); ?>">Certificates</a></li>
    <li class="active"><a href="<?php echo e(url('admin/certificates/create')); ?>"><?php echo $__env->yieldContent('title'); ?></a></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_custom'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />

<style type="text/css">
	.select2-container .select2-selection--single{
		height: 34px;
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="content">

		<?php echo Form::model($cert, ['route' => ['certificates.update', $cert->id], 'files'=>true, 'method' => 'PUT']); ?>


		<div id="ajaxLoad">

		<?php if($errors->any()): ?>
		    <div class="alert alert-danger">
		        <ul>
		            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                <li><?php echo e($error); ?></li>
		            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </ul>
		    </div>
		<?php endif; ?>

		<?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
    <?php endif; ?>

		<div class="box box-success">
	    <div class="box-header with-border">
	      <h3 class="box-title">Certificate</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-minus"></i></button>
	      </div>
	    </div>
		    
		  <div class="box-body">
		    <div class="row">

		        <div class="col-xs-12">

              <div class="form-horizontal">

	              	<div class="row">

	              		
	              		<div class="col-md-6">
			                <div class="form-group">
			                  <label for="company_id" class="col-sm-3 control-label">Company Name</label>

			                  <div class="col-sm-9">
			                    <?php echo Form::select('company_id', $companies, null, ['placeholder' => 'Pilih Salah satu', 'class' => 'form-control sel2']); ?>

			                  </div>
			                </div>

			                <div class="form-group">
			                  <label for="certificate_no" class="col-sm-3 control-label">Certificate No</label>

			                  <div class="col-sm-9">
			                    <?php echo Form::text('certificate_no', null, ['placeholder' => 'Certificate No', 'class' => 'form-control']); ?>

			                  </div>
			                </div>
		                </div>
		                

		                
		                <div class="col-md-6">
		                	<div class="form-group">
			                  <label for="file" class="col-sm-3 control-label">File</label>
			                  <div class="col-sm-9">
			                    <?php echo Form::file('file', array('class' => 'form-control text-center')); ?>

			                  </div>
			                </div>

			                <?php if($cert->id): ?>
				                <div class="form-group">
				                  <label for="status" class="col-sm-3 control-label">Status</label>

				                  <div class="col-sm-9">
				                  	<?php echo Form::select('status', $status, null, ['placeholder' => 'Pilih Salah satu', 'class' => 'form-control sel2']); ?>

				                  </div>
				                </div>
			                <?php endif; ?>
		                </div>
		                

	                </div>
	            </div>

	            <hr style="border: 1px dashed #000;" />
	            
	            <div>
	            	<a href="<?php echo e(url(Storage::url($cert->file))); ?>">
		            <img src="<?php echo e(url(Storage::url($cert->file))); ?>" 
		            title="<?php echo e($cert->certificate_no); ?>" class="img-responsive"
		            style="display: block;
										    margin-left: auto;
										    margin-right: auto;
										    width: 20%;" />
								</a>
	            </div>

		      	</div>

		    </div><!-- /.box-body -->
		  </div>
		</div>

	  <div class="panel">
			<div class="panel-body">
				<div class="row">
					<div class="col-md-offset-5 col-md-2 text-center">
						<a href="#" class="btn btn-default">Cancel</a>
						&nbsp;
						<input type="submit" value="Save" class="btn btn-primary" />
					</div>
				</div>
			</div>
		</div>

		</div> 

		<?php echo Form::close(); ?>


	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addingFileJs'); ?>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addingScriptJs'); ?>
	<script type="text/javascript">
	$(document).ready(function() {
			
	    $('.sel2').select2();

	});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
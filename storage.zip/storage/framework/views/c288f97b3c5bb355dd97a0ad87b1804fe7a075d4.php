<!-- Left side column. contains the sidebar -->
<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">

    <ul class="sidebar-menu" data-widget="tree">

      <li class="header">MAIN NAVIGATION</li>

      <li class="<?php echo e(Route::currentRouteName() == 'home'?'active':''); ?>">
        <a href="<?php echo e(route('home')); ?>">
          <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>

      <li class="<?php echo e(Route::currentRouteName() == 'persons.index'?'active':''); ?>">
        <a href="<?php echo e(route('persons.index')); ?>">
          <i class="fa fa-user"></i> <span>Person</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>

      <li class="<?php echo e(Route::currentRouteName() == 'companies.index'?'active':''); ?>">
        <a href="<?php echo e(route('companies.index')); ?>">
          <i class="fa fa-building" aria-hidden="true"></i> <span>Company</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>

      <li class="<?php echo e(Route::currentRouteName() == 'nodes.index'?'active':''); ?>">
        <a href="<?php echo e(route('nodes.index')); ?>">
          <i class="fa fa-files-o"></i>
          <span>Content Management</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>

      <li class="treeview <?php echo e(Route::currentRouteName() == 'products.index'?'active':''); ?>">
        <a href="#">
          <i class="fa fa-tasks" aria-hidden="true"></i>
          <span>Product</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
          <li class="<?php echo e(Route::currentRouteName() == 'products.index'?'active':''); ?>">
            <a href="<?php echo e(route('products.index')); ?>"><i class="fa fa-circle-o"></i> List</a>
          </li>
        </ul>
      </li>


      <li class="<?php echo e(Route::currentRouteName() == 'certificates.index'?'active':''); ?>">
        <a href="<?php echo e(route('certificates.index')); ?>">
          <i class="fa fa-file-pdf-o" aria-hidden="true"></i>
          <span>Certificate</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
      </li>

      
      <li class="header">LABELS</li>
      <li><a href="#"><i class="fa fa-circle-o text-red"></i> <span>Important</span></a></li>
      <li><a href="#"><i class="fa fa-circle-o text-yellow"></i> <span>Warning</span></a></li>
      <li><a href="#"><i class="fa fa-circle-o text-aqua"></i> <span>Information</span></a></li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>

<?php $__env->startSection('title'); ?>
Content Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('titlecontent'); ?>
Content Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('subtitlecontent'); ?>
List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<section class="content">

		<?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
          <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
    <?php endif; ?>

	  <!-- Default box -->
	  <div class="box">
	    <div class="box-header with-border">
	      <h3 class="box-title">Conten Management Page</h3>

	      <div class="box-tools pull-right">
	        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
	                title="Collapse">
	          <i class="fa fa-minus"></i></button>
	        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
	          <i class="fa fa-times"></i></button>
	      </div>
	    </div>
	    <div class="box-body">
	      <div class="row">
	      	<div class="col-md-3">
	      		<div class="lvl1">
		      		<div class="h-new-node">
		      			<img src="<?php echo e(asset('images/folder1.png')); ?>" class="img-responsive" />
		      		</div>
		      		<div class="h-new-title">
		      			<a href="<?php echo e(route('nodes.create', ['parent' => 0, 'lvl' => 1])); ?>">New Node</a>
		      		</div>

		      		<div class="clearfix"></div>

		      		<div class="b-node">
		      			<?php $__currentLoopData = $nodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		      			<div class="c-menu-b">
			      			<div class="h-new-node">
			      				<a href="<?php echo e(URL::asset('/admin/nodes')); ?>?parent=$node->node->id/2/ajaxnode"
			      					id="<?php echo e($node->node->id); ?>" class="lvl1clicked">
				      				<img src="<?php echo e(asset('images/folder1.png')); ?>" class="img-responsive" />
				      			</a>
				      		</div>
				      		<div class="h-new-title">
				      			<a href="<?php echo e(route('nodes.edit', ['id' => $node->node->id, 'parent' => session()->get('lvl1Val'), 'lvl' => $lvl])); ?>"><?php echo e($node->node->title); ?> (<?php echo e($node->node->id); ?>)</a>
				      		</div>

				      		<div class="clearfix"></div>
			      		</div>
			      		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		      		</div>
	      		</div>

	      		<hr />
	      	</div>

	      	<div class="col-md-3 ajavlvl2">
	      		<hr />
	      	</div>

	      	<div class="col-md-3 ajavlvl3">
	      		<hr />
	      	</div>

	      	<div class="col-md-3 ajavlvl4">
	      		<hr />
	      	</div>

	      </div>
	    </div>
	    <!-- /.box-body -->
	    <div class="box-footer">
	      Footer
	    </div>
	    <!-- /.box-footer-->
	  </div>
	  <!-- /.box -->

	</section>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('addingScriptJs'); ?>
  <script type="text/javascript">

    $(document).ready(function(){

      $("body").on('click', '.lvl1clicked', function(e){
      	e.preventDefault();
      	var Parent = "<?php echo e(URL::asset('/admin/nodes')); ?>/"+$(this).attr('id')+"/2/ajaxnode";
      	$(".ajavlvl2").load(Parent);
      	$(".ajavlvl3load").remove();
      	$(".ajavlvl4load").remove();
      });

      $("body").on('click', '.lvl2clicked', function(e){
      	e.preventDefault();
      	var Parent = "<?php echo e(URL::asset('/admin/nodes')); ?>/"+$(this).attr('id')+"/3/ajaxnode";
      	$(".ajavlvl3").load(Parent);
      	$(".ajavlvl4load").remove();
      });

      $("body").on('click', '.lvl3clicked', function(e){
      	e.preventDefault();
      	var Parent = "<?php echo e(URL::asset('/admin/nodes')); ?>/"+$(this).attr('id')+"/4/ajaxnode";
      	$(".ajavlvl4").load(Parent);
      	//$(".ajavlvl4load").remove();
      });

    });

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
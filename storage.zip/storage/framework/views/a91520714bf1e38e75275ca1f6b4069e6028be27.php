<!DOCTYPE html>
<html lang="en">
<head>

  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <meta property="og:locale" content="nb_NO" />

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="keywords"    content="">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link rel="shortcut icon" type="image/png" href="<?php echo e(URL::asset('assets/img/iconchange66.png')); ?>" />

  <title><?php echo $__env->yieldContent('title'); ?></title>

  <!-- Bootstrap core CSS -->
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


  <!-- Custom fonts for this template -->
  <link href="<?php echo e(URL::asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Cabin:700' rel='stylesheet' type='text/css'>


  <!-- Custom styles for this template -->
  <link href="<?php echo e(URL::asset('assets/css/grayscale.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/css/slidequote.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(URL::asset('assets/css/content.css')); ?>" rel="stylesheet">
  <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">

  <?php echo $__env->yieldContent('addingStyle'); ?>
  <link href="<?php echo e(URL::asset('css/style-ari-front.css')); ?>" rel="stylesheet">

  <!-- <link href="css/bootstrap-4-hover-navbar.css" rel="stylesheet"> -->

</head>
<a href="/internett1/index.php?t=publish.index&inline=edit" accesskey="E"></a>

<body id="page-top">


  <nav class="menuatas navbar navbar-default" style="background-color: #3a3838;border-color: #3a3838;">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar" style="background-color: white;"></span>
          <span class="icon-bar" style="background-color: white;"></span>
          <span class="icon-bar" style="background-color: white;"></span>
        </button>
         <a class="" href="/">
          <img src="<?php echo e(URL::asset('assets/img/logochange66.png')); ?>" style="height:53px; width:193px" alt="" />
        </a>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
         <ul class="nav navbar-nav" style="text-transform: uppercase;font-family: Cabin,'Helvetica Neue',Helvetica,Arial,sans-serif;"><!-- mx-auto -->
          <?php $__currentLoopData = Menus::getNavbar(['NodeID' => Menus::getLangNode()]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if( count( Menus::getNavbar(['NodeID' => $menu->id]) ) > 0 ): ?>

              <li class="dropdown">
                <?php if($menu->id == 32): ?>
                  <a href="<?php echo e($menu->alias); ?>" class="nav-link js-scroll-trigger"> <?php echo e($menu->title); ?>

                    <b class="caret"></b>
                  </a>
                <?php else: ?>
                  <a href="/<?php echo e($menu->alias); ?>" class="nav-link js-scroll-trigger"> <?php echo e($menu->title); ?>

                    <b class="caret"></b>
                  </a>
                <?php endif; ?>
                  <ul class="dropdown-menu" style="background-color: #909090;border: 0px solid rgba(0,0,0,.15);margin-top: 24px;">
                    <?php $__currentLoopData = Menus::getNavbar(['NodeID' => $menu->id, 'whereNotIn' => [30]]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menusub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><a href="/<?php echo e($menusub->alias); ?>" class="nav-link"><?php echo e($menusub->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
              </li>

            <?php else: ?>

              <li>
                <a href="/<?php echo e($menu->alias); ?>" class="nav-link js-scroll-trigger"><?php echo e($menu->title); ?></a>
              </li>

            <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(route('registerfronts')); ?>" class="nav-link js-scroll-trigger"><?php echo e(Menus::getLanguageString('idRegister3')); ?></a></li>
          
        </ul>
        <div class="my-2 my-lg-0" style="padding:12px;display: inline-block;">
          <a href="<?php echo e(route('changeLanguage', ['langID' => 'no'])); ?>">
            <img src="<?php echo e(URL::asset('assets/img/norwegia.png')); ?>" style="height:18px; width:23px;" alt="" />
          </a>
          <a href="<?php echo e(route('changeLanguage', ['langID' => 'en'])); ?>">
            <img src="<?php echo e(URL::asset('assets/img/flag-US.png')); ?>" style="height:18px; width:23px;" alt="" />
          </a>
         </div>
      </div><!-- /.navbar-collapse -->

    </div>
  </nav>


  <!-- Navigation -->
  

<!-- Intro Header -->

<?php echo $__env->yieldContent('content'); ?>



<section id="kontakt" class="content-section2 text-center hilang" style="background-color: #3a3838;">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 mx-auto">
        <h3><strong><?php echo e(Menus::getLanguageString('idContactUs')); ?></strong></h3>
      </div>
    </div>
  </div>
</section>

<section id="footer" class="content-section text-center masthead3 hilang">
        <div class="container">

          <div class="col-lg-12 mx-auto">
            <h2 class="major"><?php echo e(Menus::getLanguageString('idDYHAQuestions')); ?></h2>
            <p>
              <?php echo e(Menus::getLanguageString('idContactText')); ?>

            </p>
            <div class="well well-sm" style="background-color: transparent;border: none;">


              <div class="row">
                <div class="col-lg-5">

                  <form action="/" method="post">
                    <div class="form-group transparan">
                      <input type="text" class="form-control" name="first_name" value="" placeholder="<?php echo e(Menus::getLanguageString('idFirstName')); ?>">
                    </div>
                    <div class="form-group transparan">
                      <input type="text" class="form-control" name="last_name" value="" placeholder="<?php echo e(Menus::getLanguageString('idLastName')); ?>">
                    </div>
                    <div class="form-group transparan">
                      <input type="email" class="form-control" name="email" value="" placeholder="<?php echo e(Menus::getLanguageString('idEmail')); ?>">
                    </div>
                    <div class="form-group transparan">
                      <input type="tel" class="form-control" name="phone" value="" placeholder="<?php echo e(Menus::getLanguageString('idPhoneNumber')); ?>">
                    </div>
                    <div class="form-group transparan">
                      <textarea class="form-control" name="message" rows="3" placeholder="<?php echo e(Menus::getLanguageString('idMessage')); ?>"></textarea>
                    </div>

                    <!-- <div class="form-group transparan" style=" text-align: left;">
                                    <img src="https://www.wisehouse.no/internett1/captcha/captchasecurityimages.php?characters=7&width=120&height=35">
                                    <br><br>
                                    <input placeholder="Captcha"  name="captcha" class="form-control" required="">
                    </div> -->

                    <input type="hidden" name="contactus" value="1">
                    <input type="hidden" value="contact" name="from" />

                    <button class="btn btn-default" type="submit" name="action_publish_contactUs">
                      <i class="fa fa-paper-plane-o" aria-hidden="true"></i> <?php echo e(Menus::getLanguageString('idSubmit')); ?>

                    </button>
                  </form>
                </div>


                <div class="col-lg-7" style="text-align:left;line-height:2">

                  <ul class="contact">
                    <li class="fa-home">
                      WiseHouse AS<br />
                      Solbærvegen 5<br />
                      Elverum 2409                    </li>

                    <li class="fa-phone">+4793440771<br /></li>
                    <li class="fa-envelope"><a href="#">post@wisehouse.no</a></li>
                    <li class="fa-facebook"><a href="https://www.facebook.com/Wisehouse-Tools-382099292184354/">facebook.com</a></li>
                    <li class="fa-linkedin">
                      <a href="https://www.linkedin.com/company-beta/11119803">Linkedin.com</a>
                    </li>
                    <li class="fa-instagram"><a href="https://instagram.com/">instagram.com</a></li>
                    
                  </ul>
                </div>

              </div>
            </div>
          </div>

        </section>



        <!-- Footer -->
        <footer style="background-color: #3a3838;">
          <div class="container text-center hilang">
            <p>Copyright &copy; WiseHouse 2018</p>
            <?php if(session()->get('LanguageID') == 'no'): ?>
              <p><a href="<?php echo e(url('/no/Personvernerklæring')); ?>"><?php echo e(Menus::getLanguageString('idTermsOfUse')); ?></a></p>
              <ul class="list-unstyled">
                <?php $__currentLoopData = Menus::getNavbar(['NodeID' => 48]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menusub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="/<?php echo e($menusub->alias); ?>" class="nav-link"><?php echo e($menusub->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php elseif(session()->get('LanguageID') == 'en'): ?>
              <p><a href="<?php echo e(url('en/Privacy_Statement')); ?>"><?php echo e(Menus::getLanguageString('idTermsOfUse')); ?></a></p>
              <ul class="list-unstyled">
                <?php $__currentLoopData = Menus::getNavbar(['NodeID' => 59]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menusub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><a href="/<?php echo e($menusub->alias); ?>" class="nav-link"><?php echo e($menusub->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            <?php endif; ?>

           
          </div>
        </footer>

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-1857730-54"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());

          gtag('config', 'UA-1857730-54');
        </script>

        <!-- Bootstrap core JavaScript -->
        <script src="<?php echo e(URL::asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
        
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

        <!-- Plugin JavaScript -->
        <script src="<?php echo e(URL::asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

        <!-- Custom scripts for this template -->
        <script src="<?php echo e(URL::asset('assets/js/grayscale.min.js')); ?>"></script>

        <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
        <script>

          $(document).ready(function(){
            $(".imgblog img").addClass("img-fluid");

          });

          // var slideIndex = 0;
          // var clicked = 1;
          // showSlides(slideIndex);

          // function plusSlides(n) {
          //   // showSlides(slideIndex += n);
          //   if(n == -1){
          //     showSlides(slideIndex += n, -1, clicked);
          //   }else{
          //     showSlides(slideIndex += n, 1, clicked);
          //   }
          // }

          // function currentSlide(n) {
          //   showSlides(slideIndex = n);
          // }

          // function showSlides(n, min1 = 0, cliked = 0) {
          //   var i;
          //   var slides = document.getElementsByClassName("mySlides");
          //   var dots = document.getElementsByClassName("gmslide");
          //   if (n > slides.length) {slideIndex = 0}
          //     if (n < 0) {slideIndex = slides.length}
          //       for (i = 0; i < slides.length; i++) {
          //         slides[i].style.display = "none";
          //       }
          //       for (i = 0; i < dots.length; i++) {
          //         dots[i].className = dots[i].className.replace(" active", "");
          //       }
          //       if(cliked == 0){

          //           if(slideIndex >= slides.length){
          //             slideIndex = 1;
          //           }else{
          //             slideIndex++;
          //           }

          //           slides[slideIndex-1].style.display = "block";
          //           dots[slideIndex-1].className += " active";
          //           setTimeout(showSlides, 5000);

          //       }else{
          //         if(min1 == -1){
          //           if (n <= 0) {slideIndex = slides.length}
          //           slides[slideIndex-1].style.display = "block";
          //           dots[slideIndex-1].className += " active";
          //           //setTimeout(showSlides, 5000);

          //         }else{
          //           if(slideIndex >= slides.length){
          //             slideIndex = 1;
          //           }else{
          //             slideIndex++;
          //           }

          //           slides[slideIndex-1].style.display = "block";
          //           dots[slideIndex-1].className += " active";
          //           //setTimeout(showSlides, 5000);
          //         }
          //       }

          //       // slides[slideIndex-1].style.display = "block";
          //       // dots[slideIndex-1].className += " active";
          //       // setTimeout(showSlides, 2000);
          //     }
        </script>

        <script src="https://cloud.tinymce.com/stable/tinymce.min.js?apiKey=xspx9ax4f39yi8pjfnpoe60sz9x5mz1xewzmxt918nsl47sh"></script>

        <script type="text/javascript">

              $(function(){
              $(".dropdown").hover(
                    function() {
                        $('.dropdown-menu', this).stop( true, true ).fadeIn("fast");
                        $(this).toggleClass('open');
                        $('b', this).toggleClass("caret caret-up");
                    },
                    function() {
                        $('.dropdown-menu', this).stop( true, true ).fadeOut("fast");
                        $(this).toggleClass('open');
                        $('b', this).toggleClass("caret caret-up");
                    });
            });

            tinymce.init({
              selector: '.mceEditor',
              entity_encoding : 'raw',
              mode : 'specific_textareas',
              //selector: 'textarea',
              //editor_selector : 'mceEditor',
              convert_urls: false,
              language : 'en',
              theme: 'modern',
              plugins: [
                'spellchecker,pagebreak,layer,table,save,insertdatetime,media,searchreplace,' +
                  'print,contextmenu,paste,directionality,fullscreen,noneditable,visualchars,' +
                  'nonbreaking,template,autoresize,' +
                  'anchor,charmap,hr,image,link,emoticons,code,textcolor,' +
                  'charmap,pagebreak'
              ],
              toolbar: 'insertfile undo redo| charmap | pagebreak | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image |  fontselect fontsizeselect | forecolor backcolor',
              pagebreak_separator: "<!-- my page break -->",
              image_advtab: true,
              autoresize_max_height: 350
            });
        </script>

          <?php echo $__env->yieldContent('addingScriptJs'); ?>
    </body>
</html>

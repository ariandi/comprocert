  <!-- Default box -->
  <div class="box">
    <div class="box-header with-border">
      <h3 class="box-title">Update Content Management Page</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i></button>
      </div>
    </div>
    <div class="box-body">
      <div class="nav-tabs-custom">
        <ul class="nav nav-tabs">
          <li class="active"><a href="#node_detail" data-toggle="tab" aria-expanded="true">Node Detail</a></li>
          <li class="pull-right"><a href="<?php echo e(route('nodes.index')); ?>" class="text-muted">Back to list</a></li>
        </ul>
        <div class="tab-content">
          <div class="tab-pane active" id="node_detail">

            <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
            <?php endif; ?>

              <div class="box-body">
                  <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
                    <?php echo e(Form::label('title', 'Title')); ?>

                    <?php echo e(Form::text('title', $nodes->title, array('class' => 'form-control'))); ?>


                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>

                  <div class="form-group <?php echo e($errors->has('template') ? 'has-error' : ''); ?>">
                    <?php echo e(Form::label('template', 'Templates')); ?>

                    <?php echo e(Form::select('template', $arrTemplates, $nodes->template,
                                    ['placeholder' => 'Pick a Template...', 'class' => 'form-control'])); ?>


                    <?php if($errors->has('keyword')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('keyword')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>


                  <div class="form-group <?php echo e($errors->has('alias') ? 'has-error' : ''); ?>">
                    <?php echo e(Form::label('alias', 'Alias')); ?>

                    <?php echo e(Form::text('alias', $nodes->alias, array('class' => 'form-control'))); ?>


                    <?php if($errors->has('alias')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('alias')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>

                  <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                    <?php echo e(Form::label('description', 'Description')); ?>

                    <?php echo e(Form::text('description', $nodes->description, array('class' => 'form-control'))); ?>


                    <?php if($errors->has('description')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>

                  <div class="form-group <?php echo e($errors->has('keyword') ? 'has-error' : ''); ?>">
                    <?php echo e(Form::label('keyword', 'Keyword')); ?>

                    <?php echo e(Form::text('keyword', $nodes->keyword, array('class' => 'form-control'))); ?>


                    <?php if($errors->has('keyword')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('keyword')); ?></strong>
                        </span>
                    <?php endif; ?>
                  </div>

                  <div class="form-group <?php echo e($errors->has('active') ? 'has-error' : ''); ?>">
                    <?php echo e(Form::label('active', 'Active')); ?>

                    <?php echo e(Form::checkbox('active', 1, $nodes->active, ['class' => ''])); ?>

                  </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
              
          </div>
          <!-- /.tab-pane -->
          
        </div>
        <!-- /.tab-content -->
      </div>

    </div>
    <!-- /.box-body -->
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->
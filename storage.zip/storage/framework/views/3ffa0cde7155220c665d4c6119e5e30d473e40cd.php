<?php $__env->startSection('title'); ?> Edit Person <?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<h1><?php echo $__env->yieldContent('title'); ?><!-- <small></small> --></h1>
<ol class="breadcrumb">
	<li><a href=""><i class="fa fa-dashboard"></i> Dashboard</a></li>
	<li><a href="<?php echo e(route('persons.index')); ?>">Person</a></li>
	<li class="active"><?php echo $__env->yieldContent('title'); ?></li>
</ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css_custom'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/css/bootstrap-datepicker.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="content">

	<div class="row" style="margin-bottom:15px;">
		<div class="col-md-4">
			<button type="button" class="btn btn-success btn-block userTarget" 
			target="<?php echo e(route('person.edit-ajax', $user['data']->id)); ?>">User Detail</button>
		</div>

		<div class="col-md-4">
			<button type="button" class="btn btn-success btn-block userTarget" 
			target="<?php echo e(route('person.person-role', $user['data']->id)); ?>">User Role</button>
		</div>
	</div>

	<form method="post" action="<?php echo e(route('persons.update', [$user['data']->id])); ?>">
		<?php echo method_field('PUT'); ?>
		<?php echo csrf_field(); ?>
		<div id="ajaxLoad">
		<div class="box box-default" id="box-personInformation">
			<div class="box-header with-border" id="box-personInformation-collapse-trigger" style="cursor: pointer;">
				<h3 class="box-title">Person Information</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<div class="box-body">
				<div class="row">
					<!-- <div class="col-md-12">
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($message); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div> -->
					<?php if(\Session::has('success')): ?>
					<div class="col-md-12">
						<div class="alert alert-success">
							<p><?php echo e(\Session::get('success')); ?></p>
						</div>
					</div>
					<?php endif; ?>
					<div class="col-md-6">
						<div class="form-group">
							<label for="firstName">First Name</label>
							<input type="text" name="first_name" id="first_name" value="<?php echo e($user['data']->first_name); ?>" class="form-control" />
							<small class="text-red"><?php echo e($errors->first('first_name')); ?></small>
						</div>
						<div class="form-group">
							<label for="birthDate">Date of birth</label>
							<div class="input-group date">
								<span class="input-group-addon">
			                        <i class="fa fa-calendar"></i>
			                    </span>
			                    <input type="text" name="birth_date" id="birth_date" value="<?php echo e($user['data']->birth_date); ?>" class="form-control" readonly="" />
			                </div>
			                <small class="text-red"><?php echo e($errors->first('birth_date')); ?></small>
						</div>
						<div class="form-group">
							<label for="email">E-mail</label>
							<input type="email" name="email" id="email" value="<?php echo e($user['data']->email); ?>" class="form-control" />
							<small class="text-red"><?php echo e($errors->first('email')); ?></small>
						</div>
						<div class="form-group">
							<label for="password">Password</label>
							<input type="password" name="passwordold" id="password" class="form-control" />
							<small class="text-red"><?php echo e($errors->first('password')); ?></small>
						</div>
						<div class="form-group">
							<label for="confirmPassword">Confirm Password</label>
							<input type="password" name="password_confirmationold" id="confirmPassword" class="form-control" />
							<small class="text-red"><?php echo e($errors->first('password_confirmation')); ?></small>
						</div>
						<div class="form-group">
							<label for="company">Company(s)</label>
							<select class="js-example-basic-multiple form-control" name="companies[]" multiple="multiple">
							<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($company->id); ?>" <?php echo e(((in_array($company->id, $user['hasCompany'])) ? 'selected':'')); ?> ><?php echo e($company->CompanyName); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<small class="text-red"><?php echo e($errors->first('companies')); ?></small>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="lastName">Last Name </label>
							<input type="text" name="last_name" id="last_name" value="<?php echo e($user['data']->last_name); ?>" class="form-control" />
							<small class="text-red"><?php echo e($errors->first('last_name')); ?></small>
						</div>
						<div class="form-group">
							<label for="gender">Gender</label>
							<?php echo e(Form::select('gender', ['M' => 'Male', 'F' => 'Female'], $user['data']->gender, ['placeholder' => 'Select Gender', 'class' => 'form-control', 'id' => 'gender' ])); ?>

							<small class="text-red"><?php echo e($errors->first('gender')); ?></small>
						</div>
						<div class="form-group">
							<label for="mobilePhoneNumber">Mobile Phone</label>
							<input type="text" name="no_hp" id="no_hp" value="<?php echo e($user['data']->no_hp); ?>" class="form-control" />
							<small class="text-red"><?php echo e($errors->first('no_hp')); ?></small>
						</div>
						<div class="form-group">
							<label for="languageID">Language</label>
							<?php echo e(Form::select('lang_id', $languages, $user['data']->lang_id, ['placeholder' => 'Select Language', 'class' => 'form-control', 'id' => 'lang_id' ])); ?>

							<small class="text-red"><?php echo e($errors->first('lang_id')); ?></small>
						</div>
						<div class="form-group">
							<label for="role">Role</label>
							<?php echo e(Form::select('role', $roles, $user['data']->role, ['placeholder' => 'Select Role', 'class' => 'form-control', 'id' => 'role' ])); ?>

							<small class="text-red"><?php echo e($errors->first('role')); ?></small>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="box box-default" id="box-invoiceAddress"> <!-- .collapsed-box is name class for collapse box by default -->
			<div class="box-header with-border" id="box-invoiceAddress-collapse-trigger" style="cursor: pointer;">
				<h3 class="box-title">Invoice Address</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<div class="box-body">
				<div class="row">
					<div class="col-md-12">
						Coming Soon
					</div>
				</div>
			</div>
		</div>
		<div class="box box-default" id="box-deliveryAddress">
			<div class="box-header with-border" id="box-deliveryAddress-collapse-trigger" style="cursor: pointer;">
				<h3 class="box-title">Delivery Address</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<div class="box-body">
				<div class="row">
					<div class="col-md-12">
						Coming Soon
					</div>
				</div>
			</div>
		</div>
		<div class="box box-default" id="box-variousInformation">
			<div class="box-header with-border" id="box-variousInformation-collapse-trigger" style="cursor: pointer;">
				<h3 class="box-title">Various information</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<div class="box-body">
				<div class="row">
					<div class="col-md-12">
						Coming Soon
					</div>
				</div>
			</div>
		</div>
		<div class="box box-default" id="box-log">
			<div class="box-header with-border" id="box-log-collapse-trigger" style="cursor: pointer;">
				<h3 class="box-title">Log</h3>
				<div class="box-tools pull-right">
					<button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				</div>
			</div>
			<div class="box-body">
				<div class="row">
					<div class="col-md-12">
						Coming Soon
					</div>
				</div>
			</div>
		</div>
		<div class="panel">
			<div class="panel-body">
				<div class="row">
					<div class="col-md-offset-5 col-md-2 text-center">
						<a href="<?php echo e(route('persons.index')); ?>" class="btn btn-default">Cancel</a>
						&nbsp;
						<button type="submit" class="btn btn-primary">Save</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	</form>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_custom'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.8.0/js/bootstrap-datepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {

	$('#birth_date').datepicker({
		autoclose: true,
		orientation: 'bottom',
		format: 'yyyy-mm-dd',
		todayHighlight: true
  });

	$('body').on('click', '.userTarget', function(){
		var target = $(this).attr('target');
		// var thirdparty = $(this).attr('thirdparty');

		$.ajax({
	    method:"GET",
	    url:target,
	    success: function(result){
	        $("#ajaxLoad").html(result);

	        $('#birthDate').datepicker({
						autoclose: true,
						orientation: 'bottom',
						format: 'dd MM yyyy',
						startView: 4
			    });

			    $('.js-example-basic-multiple').select2({
			    	maximumSelectionLength: 5
			    });

			    $.each(['personInformation', 'invoiceAddress', 'deliveryAddress', 'variousInformation', 'log'], function(key, value) {
						$('#box-' + value + '-collapse-trigger').on('click', function() {
							$('#box-' + value).boxWidget('toggle');
						});
					});

					var table = $('.datatable').DataTable({
	        processing: true,
	        serverSide: true,
	        ajax: '<?php echo e(route('person.list-of-role', $user['data']->id)); ?>',
			        columns: [
			            {data: 'id', name: 'id'},
			            {data: 'RoleName', name: 'RoleName'},
			            {data: 'Description', name: 'Description'},
			            {data: 'action', name: 'action', orderable: false, searchable: false}
			        ]
			    });

					var i = 1;
			    $('body').on('click', '.insertRole', function( event ) {
						  event.preventDefault();
						  var role_id = $(this).attr('role_id');
						  var formData = {
			            user_id : $('#user_id_'+role_id).val(),
			            role_id : role_id,
			            _token  : $('meta[name="csrf-token"]').attr('content'),
			            _method: 'post',
			        }
			        console.log(formData);
			        $.ajax({
			            type: 'post',
			            url: '<?php echo e(url('admin/persons/input-person-role')); ?>/'+formData.user_id+'/'+formData.role_id,
			            data: formData,
			        }).done(function (data) {
			            if(data.error == '0'){
			            	alert('input data success');
			            	table.ajax.reload();
			            	$("#personRole").load("<?php echo e(route('person.person-role',$user['data']->id)); ?> #box-personRole");
			            }else{
			            	alert('error');
			            }
			        });
			    });

				  $('body').on('click', '.remove-person-role', function(event){
			    		event.preventDefault();
			    		var id = $(this).attr('id');
						  var formData = {
			            _token  : $('meta[name="csrf-token"]').attr('content'),
			            _method: 'delete',
			        }
			        console.log(formData);
			        $.ajax({
			            type: 'post',
			            url: '<?php echo e(url('admin/persons/delete-person-role/')); ?>/'+id,
			            data: formData,
			        }).done(function (data) {
			            if(data.error == '0'){
			            	alert('remove data success');
			            	table.ajax.reload();
			            	$("#personRole").load("<?php echo e(route('person.person-role',$user['data']->id)); ?> #box-personRole");
			            }else{
			            	alert('error');
			            }
			        });
			    });

			    i = i+1;
			    console.log(i);

	    },
	    error: function(e){
	      alert("Error");
	      console.log(e);
	    }
	  });
	});

	

	// $( "form#personRoleForm" ).on( "submit", function( event ) {
	//   event.preventDefault();
	// });
});
</script>

<script type="text/javascript">	
$(function () {
	$('#birthDate').datepicker({
		autoclose: true,
		orientation: 'bottom',
		format: 'dd MM yyyy',
		startView: 4
    });

    $('.js-example-basic-multiple').select2({
    	maximumSelectionLength: 5
    });
});
</script>

<script>
$(function () {
	$.each(['personInformation', 'invoiceAddress', 'deliveryAddress', 'variousInformation', 'log'], function(key, value) {
		$('#box-' + value + '-collapse-trigger').on('click', function() {
			$('#box-' + value).boxWidget('toggle');
		});
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
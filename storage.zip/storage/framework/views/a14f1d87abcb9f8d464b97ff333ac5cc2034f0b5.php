<?php $__env->startSection('title'); ?>
WCS Indonesia | Certification Body
<?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>
    $(document).ready(function(){
     
    });
  </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
  
  <!--====================================================
                           HOME
  ======================================================-->
  <section id="home">
    <div id="carousel" class="carousel slide carousel-fade" data-ride="carousel"> 
      <!-- Carousel items -->
      <div class="carousel-inner">
          <div class="carousel-item active slides">
            <div class="overlay"></div>
            <div class="slide-1"></div>
              <div class="hero ">
                <hgroup class="wow fadeInUp">
                    <h1>We Help <span ><a href="" class="typewrite" data-period="2000" data-type='[ " Certification", " Training"]'>
                      <span class="wrap"></span></a></span> </h1>
                    <h3>Welcome to WCS Indonesia</h3>        
                    <h3>World Certification Services (WCS) is a UKAS Accredited Certification Body providing Assessment and Certification Services against many international standards, including ISO 9001, ISO 14001 and OHSAS 18001.</h3>
                </hgroup>
                <button class="btn btn-general btn-green wow fadeInUp" role="button">Contact Now</button>
              </div>           
          </div> 
      </div> 
    </div> 
  </section> 

  <!--====================================================
                          ABOUT
  ======================================================-->
  <section id="about" class="about">
    <div class="container">
      <div class="row title-bar">
        <div class="col-md-12">
          <h1 class="wow fadeInUp"><?php echo e($homeContent1->title); ?></h1>
          <div class="heading-border"></div>
          <p class="wow fadeInUp" data-wow-delay="0.4s"><?php echo $homeContent1->content2; ?></p>
          <div class="title-but">
            <a class="btn btn-general btn-green" role="button" href="<?php echo $homeContent1->alias; ?>">Read More</a>
          </div>
        </div>
      </div>
    </div>  
    <!-- About right side withBG parallax -->
    <div class="container-fluid">
      <div class="row"> 
        <?php $__currentLoopData = $tigaIcon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 <?php echo e($ti->alias); ?>">
            <div class="about-content-box wow fadeInUp" data-wow-delay="<?php echo e($ti->description); ?>">
              <i class="<?php echo e($ti->keyword); ?>"></i>
              <h5><?php echo e($ti->title); ?></h5>
              <p class="desc"><?php echo $ti->content1; ?></p>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div> 
    </div>       
  </section>

  <!--====================================================
                          OFFER
  ======================================================-->
  <section id="comp-offer">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-3 col-sm-6 desc-comp-offer wow fadeInUp" data-wow-delay="0.2s">
          <h2>What We Offer</h2>
          <div class="heading-border-light"></div> 
          <button class="btn btn-general btn-green" role="button">See Curren Offers</button>
          <button class="btn btn-general btn-white" role="button">Contact Us Today</button>
        </div>
        <div class="col-md-3 col-sm-6 desc-comp-offer wow fadeInUp" data-wow-delay="0.4s">
          <div class="desc-comp-offer-cont">
            <div class="thumbnail-blogs">
                <div class="caption">
                  <i class="fa fa-chain"></i>
                </div>
                <img src="<?php echo e(asset('theme/img/news/news-11.jpg')); ?>" class="img-fluid" alt="...">
            </div>
            <h3>Business Management</h3>
            <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC. </p>
            <a href="#"><i class="fa fa-arrow-circle-o-right"></i> Learn More</a>
          </div>
        </div>          
        <div class="col-md-3 col-sm-6 desc-comp-offer wow fadeInUp" data-wow-delay="0.6s">
          <div class="desc-comp-offer-cont">
            <div class="thumbnail-blogs">
                <div class="caption">
                  <i class="fa fa-chain"></i>
                </div>
                <img src="<?php echo e(asset('theme/img/news/news-13.jpg')); ?>" class="img-fluid" alt="...">
            </div>              
            <h3>Leadership Development</h3>
            <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC. </p>
            <a href="#"><i class="fa fa-arrow-circle-o-right"></i> Learn More</a>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 desc-comp-offer wow fadeInUp" data-wow-delay="0.8s">
          <div class="desc-comp-offer-cont">
            <div class="thumbnail-blogs">
                <div class="caption">
                  <i class="fa fa-chain"></i>
                </div>
                <img src="<?php echo e(asset('theme/img/news/news-14.jpg')); ?>" class="img-fluid" alt="...">
            </div>
            <h3>Social benefits and services</h3>
            <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC. </p>
            <a href="#"><i class="fa fa-arrow-circle-o-right"></i> Learn More</a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!--====================================================
                       WHAT WE DO
  ======================================================-->
  <section class="what-we-do bg-gradiant">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-3">
          <h3>What we Do</h3>
          <div class="heading-border-light"></div> 
          <p class="desc">We partner with clients to put recommendations into practice. </p>
        </div>
        <div class="col-md-9">
          <div class="row">
            <div class="col-md-4  col-sm-6">
              <div class="what-we-desc">
                <i class="fa fa-briefcase"></i>
                <h6>Workspace</h6>
                <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
              </div>
            </div>
            <div class="col-md-4  col-sm-6">
              <div class="what-we-desc">
                <i class="fa fa-shopping-bag"></i>
                <h6>Storefront</h6>
                <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
              </div>
            </div>
            <div class="col-md-4  col-sm-6">
              <div class="what-we-desc">
                <i class="fa fa-building-o"></i>
                <h6>Apartments</h6>
                <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
              </div>
            </div>
            <div class="col-md-4  col-sm-6">
              <div class="what-we-desc">
                <i class="fa fa-bed"></i>
                <h6>Hotels</h6>
                <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
              </div>
            </div>
            <div class="col-md-4  col-sm-6">
              <div class="what-we-desc">
                <i class="fa fa-hourglass-2"></i>
                <h6>Concept</h6>
                <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
              </div>
            </div>
            <div class="col-md-4  col-sm-6">
              <div class="what-we-desc">
                <i class="fa fa-cutlery"></i>
                <h6>Restaurant</h6>
                <p class="desc">Contrary to popular belief, Lorem Ipsum is not simply random text. </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>      
  </section> 

  <!--====================================================
                        STORY
  ======================================================--> 
  <section id="story">
      <div class="container">
        <div class="row title-bar">
          <div class="col-md-12">
            <h1 class="wow fadeInUp">Our Success Tranformation Story</h1>
            <div class="heading-border"></div> 
          </div>
        </div>
      </div>  
      <div class="container-fluid">
        <div class="row" >
          <div class="col-md-6" >
            <div class="story-himg" >
              <img src="<?php echo e(asset('theme/img/image-4.jpg')); ?>" class="img-fluid" alt="">
            </div>
          </div>
          <div class="col-md-6">
            <div class="story-desc">
              <h3>How to grow world with Us</h3>
              <div class="heading-border-light"></div> 
              <p>Everyone defines success differently – as much as there are people, there are different opinions. Number one in our priority list is the success of our students, alumni and their employers. We work hard in the name of the success of our alumni – being among the best and holding the high employment rate. Many desktop publishing packages and web page editors now use Lorem Ipsum.. </p>
              <p>You can find some thoughts on success from our students and alumni here – every story is unique, but this is what success is. Everybody sees it differently. Many desktop publishing packages and web page editors now use Lorem Ipsum.</p>
              <p class="text-right" style="font-style: italic; font-weight: 700;"><a href="#">Businessbox</a></p>
              <div class="title-but"><button class="btn btn-general btn-green" role="button">Read More</button></div>
            </div>
          </div>
        </div>
      </div>  
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s"> 
            <div class="story-descb">
                <img src="<?php echo e(asset('theme/img/news/news-10.jpg')); ?>" class="img-fluid" alt="...">
                <h6>Virtual training systems</h6>
                <p>Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                <a href="#"><i class="fa fa-arrow-circle-o-right"></i> Read More</a>
            </div>
          </div>
          <div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.3s"> 
            <div class="story-descb">
                <img src="<?php echo e(asset('theme/img/news/news-2.jpg')); ?>" class="img-fluid" alt="...">
                <h6>Design planning</h6>
                <p>Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                <a href=""><i class="fa fa-arrow-circle-o-right"></i> Read More</a>
            </div>
          </div>
          <div class="col-md-4 col-sm-6 wow fadeInUp" data-wow-delay="0.5s"> 
            <div class="story-descb">
                <img src="<?php echo e(asset('theme/img/news/news-8.jpg')); ?>" class="img-fluid" alt="...">
                <h6>Remote condition monitoring</h6>
                <p>Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                <a href=""><i class="fa fa-arrow-circle-o-right"></i> Read More</a>
            </div>
          </div>                        
        </div>
      </div>  
  </section>

  <!--====================================================
                    COMPANY THOUGHT
  ======================================================-->
  <div class="overlay-thought"></div>
  <section id="thought" class="bg-parallax thought-bg">
    <div class="container">
      <div id="thought-desc" class="row title-bar title-bar-thought owl-carousel owl-theme">
        <div class="col-md-12 ">
          <div class="heading-border bg-white"></div>
          <p class="wow fadeInUp" data-wow-delay="0.4s">Businessbox will deliver value to all the stakeholders and will attain excellence and leadership through such delivery of value. We will strive to support the stakeholders in all activities related to us. Businessbox provide great things.</p>
          <h6>John doe</h6>
        </div>
        <div class="col-md-12 thought-desc">
          <div class="heading-border bg-white"></div>
          <p class="wow fadeInUp" data-wow-delay="0.4s">Ensuring quality in Businessbox is an obsession and the high quality standards set by us are achieved through a rigorous quality assurance process. Quality assurance is performed by an independent team of trained experts for each project. </p>
          <h6>Tom John</h6>
        </div>
      </div>
    </div>         
  </section> 
      
  <!--====================================================
                     SERVICE-HOME
  ======================================================--> 
  <section id="service-h">
      <div class="container-fluid">
        <div class="row" >
          <div class="col-md-6" >
            <div class="service-himg" > 
              <iframe src="https://www.youtube.com/embed/754f1w90gQU?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
            </div>
          </div>
          <div class="col-md-6 wow fadeInUp" data-wow-delay="0.3s">
            <div class="service-h-desc">
              <h3>We are Providing great Services</h3>
              <div class="heading-border-light"></div> 
              <p>Businessbox offer the full spectrum of services to help organizations work better. Everything from creating standards of excellence to training your people to work in more effective ways.</p>  
            <div class="service-h-tab"> 
              <nav class="nav nav-tabs" id="myTab" role="tablist">
                <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-expanded="true">Developing</a>
                <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile">Training</a> 
                <a class="nav-item nav-link" id="my-profile-tab" data-toggle="tab" href="#my-profile" role="tab" aria-controls="my-profile">Medical</a> 
              </nav>
              <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab"><p>Nulla est ullamco ut irure incididunt nulla Lorem Lorem minim irure officia enim reprehenderit. Magna duis labore cillum sint adipisicing exercitation ipsum. Nostrud ut anim non exercitation velit laboris fugiat cupidatat. Commodo esse dolore fugiat sint velit ullamco magna consequat voluptate minim amet aliquip ipsum aute. exercitation ipsum. Nostrud ut anim non exercitation velit laboris fugiat cupidatat. Commodo esse dolore fugiat sint velit ullamco magna consequat voluptate minim amet aliquip ipsum aute. </p></div>
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                  <p>Nulla est ullamco ut irure incididunt nulla Lorem Lorem minim irure officia enim reprehenderit. Magna duis labore cillum sint adipisicing exercitation ipsum. Nostrud ut anim non exercitation velit laboris fugiat cupidatat. Commodo esse dolore fugiat sint velit ullamco magna consequat voluptate minim amet aliquip ipsum aute</p>
                </div> 
                <div class="tab-pane fade" id="my-profile" role="tabpanel" aria-labelledby="my-profile-tab">
                  <p>Nulla est ullamco ut irure incididunt nulla Lorem Lorem minim irure officia enim reprehenderit. Magna duis labore cillum sint adipisicing exercitation ipsum. Nostrud ut anim non exercitation velit laboris fugiat cupidatat. Commodo esse dolore fugiat sint velit ullamco magna consequat voluptate minim amet aliquip ipsum aute</p>
                </div> 
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>  
  </section>

  <!--====================================================
                        CLIENT
  ======================================================-->
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>